package com.chiennx.exe3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private GridView mGridView;
    private GridAdapter mGridAdapter;
    ArrayList<Item> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        items = listItem();
        mGridView = findViewById(R.id.grid);
        mGridAdapter = new GridAdapter(items, this);
        mGridView.setAdapter(mGridAdapter);
    }

    private ArrayList<Item> listItem() {
        ArrayList<Item> items = new ArrayList<>();
        items.add(new Item("Hinh 1", R.drawable.hinh_1));
        items.add(new Item("Hinh 2", R.drawable.hinh_2));
        items.add(new Item("Hinh 3", R.drawable.hinh_3));
        items.add(new Item("Hinh 4", R.drawable.hinh_4));
        items.add(new Item("Hinh 5", R.drawable.hinh_5));
        items.add(new Item("Hinh 6", R.drawable.hinh_6));
        items.add(new Item("Hinh 7", R.drawable.hinh_7));
        return items;
    }
}
