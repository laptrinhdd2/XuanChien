package com.chiennx.exe3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.TransitionInflater;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ImageView imageView = findViewById(R.id.imageTitle);
        TextView textView = findViewById(R.id.textTitle);

        Intent intent = getIntent();
        Item item = (Item) intent.getSerializableExtra("itemX");

        imageView.setImageResource(item.getmImage());
        textView.setText(item.getmName());

        getWindow().setSharedElementEnterTransition(TransitionInflater.from(this)
                .inflateTransition(R.transition.grid_detail_transition));
    }
}
