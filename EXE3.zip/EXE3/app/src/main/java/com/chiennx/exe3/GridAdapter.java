package com.chiennx.exe3;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class GridAdapter extends BaseAdapter {
    private ArrayList<Item> items;
    private Activity activity;

    public GridAdapter(ArrayList<Item> items, Activity activity) {
        this.items = items;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Holder holder;

        if (null == convertView) {
            convertView = LayoutInflater.from(activity).inflate(R.layout.item, parent, false);
            holder = new Holder();
            holder.imageView = convertView.findViewById(R.id.imageItem);
            holder.textView = convertView.findViewById(R.id.textItem);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        final Item item = items.get(position);
        holder.imageView.setImageResource(item.getmImage());
        holder.textView.setText(item.getmName());
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, DetailActivity.class);
                intent.putExtra("itemX", item);
                activity.startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(activity,
                        new Pair<View, String>(holder.imageView,
                                holder.imageView.getTransitionName()),
                        new Pair<View, String>(holder.textView,
                                holder.textView.getTransitionName())).toBundle());
            }
        });
        return convertView;
    }

    static class Holder {
        TextView textView;
        ImageView imageView;
    }
}
