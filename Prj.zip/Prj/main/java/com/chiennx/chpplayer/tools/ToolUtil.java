package com.chiennx.chpplayer.tools;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.widget.ImageView;

public class ToolUtil {

    public void setCircularImage(Context context, int drawableImage, ImageView imageViewOut) {
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), drawableImage);
        RoundedBitmapDrawable roundedBitmapDrawable = RoundedBitmapDrawableFactory.create(context.getResources(), bitmap);
        roundedBitmapDrawable.setCircular(true);
        imageViewOut.setImageDrawable(roundedBitmapDrawable);
    }
}
