package com.chiennx.chpplayer.models;

public class Actor {

    private int actorImage;
    private String actorName;
    private int total;

    public Actor() {
    }

    public Actor(int actorImage, String actorName, int total) {
        this.actorImage = actorImage;
        this.actorName = actorName;
        this.total = total;
    }

    public int getActorImage() {
        return actorImage;
    }

    public void setActorImage(int actorImage) {
        this.actorImage = actorImage;
    }

    public String getActorName() {
        return actorName;
    }

    public void setActorName(String actorName) {
        this.actorName = actorName;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
