package com.chiennx.chpplayer.models;

public class Playlist {

    private int playlistImage;
    private String playlistName;

    public Playlist() {
    }

    public Playlist(int playlistImage, String playlistName) {
        this.playlistImage = playlistImage;
        this.playlistName = playlistName;
    }

    public int getPlaylistImage() {
        return playlistImage;
    }

    public void setPlaylistImage(int playlistImage) {
        this.playlistImage = playlistImage;
    }

    public String getPlaylistName() {
        return playlistName;
    }

    public void setPlaylistName(String playlistName) {
        this.playlistName = playlistName;
    }
}
