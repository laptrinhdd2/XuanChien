package com.chiennx.chpplayer.models;

public class Song {
    private int songImage;
    private String songName;
    private String songActor;

    public Song() {
    }

    public Song(int songImage, String songName, String songActor) {
        this.songImage = songImage;
        this.songName = songName;
        this.songActor = songActor;
    }

    public int getSongImage() {
        return songImage;
    }

    public void setSongImage(int songImage) {
        this.songImage = songImage;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public String getSongActor() {
        return songActor;
    }

    public void setSongActor(String songActor) {
        this.songActor = songActor;
    }
}
