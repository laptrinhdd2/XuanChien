package com.chiennx.chpplayer.datas;

import com.chiennx.chpplayer.R;
import com.chiennx.chpplayer.models.Actor;
import com.chiennx.chpplayer.models.Playlist;
import com.chiennx.chpplayer.models.Song;

import java.util.ArrayList;

public class DataUtil {

    public ArrayList<Song> dataSong() {
        ArrayList<Song> songs = new ArrayList<>();
        songs.add(new Song(R.drawable.img_default, "Chien1", "Chien1"));
        songs.add(new Song(R.drawable.img_default, "Chien2", "Chien2"));
        songs.add(new Song(R.drawable.img_default, "Chien3", "Chien3"));
        songs.add(new Song(R.drawable.img_default, "Chien4", "Chien4"));
        songs.add(new Song(R.drawable.img_default, "Chien5", "Chien5"));
        songs.add(new Song(R.drawable.img_default, "Chien6", "Chien6"));
        songs.add(new Song(R.drawable.img_default, "Chien6", "Chien6"));
        songs.add(new Song(R.drawable.img_default, "Chien6", "Chien6"));
        songs.add(new Song(R.drawable.img_default, "Chien6", "Chien6"));
        songs.add(new Song(R.drawable.img_default, "Chien6", "Chien6"));
        return songs;
    }

    public ArrayList<Actor> dataActor() {
        ArrayList<Actor> actors = new ArrayList<>();
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        actors.add(new Actor(R.drawable.img_default, "Chien", 12));
        return actors;
    }

    public ArrayList<Playlist> dataPlaylist() {
        ArrayList<Playlist> playlists = new ArrayList<>();
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        playlists.add(new Playlist(R.drawable.img_default, "Playlist"));
        return playlists;
    }
}
