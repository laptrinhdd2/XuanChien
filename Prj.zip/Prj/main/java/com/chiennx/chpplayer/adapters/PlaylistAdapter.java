package com.chiennx.chpplayer.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.chiennx.chpplayer.R;
import com.chiennx.chpplayer.models.Playlist;

import java.util.ArrayList;

public class PlaylistAdapter extends BaseAdapter {

    Context context;
    ArrayList<Playlist> listPlaylist;

    public PlaylistAdapter(Context context, ArrayList<Playlist> listPlaylist) {
        this.context = context;
        this.listPlaylist = listPlaylist;
    }


    @Override
    public int getCount() {
        return listPlaylist.size();
    }

    @Override
    public Object getItem(int position) {
        return listPlaylist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        PlaylistHolder playlistHolder;
        if (null == convertView) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_play_list, parent, false);
            playlistHolder = new PlaylistHolder();
            playlistHolder.playlistImage = convertView.findViewById(R.id.imgImagePlaylistItem);
            playlistHolder.playlistName = convertView.findViewById(R.id.txtNamePlaylistItem);
            convertView.setTag(playlistHolder);
        } else {
            playlistHolder = (PlaylistHolder) convertView.getTag();
        }

        Playlist playlist = listPlaylist.get(position);
        playlistHolder.playlistImage.setImageResource(playlist.getPlaylistImage());
        playlistHolder.playlistName.setText(playlist.getPlaylistName());

        return convertView;
    }

    private static class PlaylistHolder {
        ImageView playlistImage;
        TextView playlistName;
    }
}
