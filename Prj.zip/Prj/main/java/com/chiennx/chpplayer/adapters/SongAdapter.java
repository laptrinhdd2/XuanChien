package com.chiennx.chpplayer.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chiennx.chpplayer.R;
import com.chiennx.chpplayer.datas.DataUtil;
import com.chiennx.chpplayer.models.Song;
import com.chiennx.chpplayer.tools.ToolUtil;

import java.util.ArrayList;

public class SongAdapter extends RecyclerView.Adapter<SongAdapter.SongViewHolder> {

    Context context;
    ArrayList<Song> listSong;
    View view;
    ToolUtil toolUtil = new ToolUtil();

    public SongAdapter(Context context, ArrayList<Song> listSong) {
        this.context = context;
        this.listSong = listSong;
    }

    @NonNull
    @Override
    public SongViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        view = LayoutInflater.from(context).inflate(R.layout.item_song, viewGroup, false);
        SongViewHolder songViewHolder = new SongViewHolder(view);

        return songViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull SongViewHolder songViewHolder, int i) {
        Song song = listSong.get(i);
        //songViewHolder.songImage.setImageResource(song.getSongImage());
        toolUtil.setCircularImage(context, song.getSongImage(), songViewHolder.songImage);
        songViewHolder.songName.setText(song.getSongName());
        songViewHolder.songActor.setText(song.getSongActor());
    }

    @Override
    public int getItemCount() {
        return listSong.size();
    }


    public class SongViewHolder extends RecyclerView.ViewHolder {
        ImageView songImage, imgPlay, btnFavorite;
        LinearLayout infoSong;
        TextView songName, songActor;

        public SongViewHolder(@NonNull View itemView) {
            super(itemView);
            songImage = itemView.findViewById(R.id.imgImageSongItem);
            imgPlay = itemView.findViewById(R.id.imgPlaySongItem);
            btnFavorite = itemView.findViewById(R.id.imgFavoriteSongItem);
            infoSong = itemView.findViewById(R.id.infoSongItem);
            songName = itemView.findViewById(R.id.txtNameSongItem);
            songActor = itemView.findViewById(R.id.txtActorSongItem);
        }
    }
}
