package com.chiennx.chpplayer.adapters;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.chiennx.chpplayer.R;
import com.chiennx.chpplayer.activities.ActorDetailActivity;
import com.chiennx.chpplayer.models.Actor;
import com.chiennx.chpplayer.tools.ToolUtil;

import java.util.ArrayList;

public class ActorAdapter extends RecyclerView.Adapter<ActorAdapter.ActorViewHolder> {
    ArrayList<Actor> listActor;
    View view;
    ToolUtil toolUtil = new ToolUtil();
    Activity host;

    public ActorAdapter(Activity activity, ArrayList<Actor> listActor) {
        this.host = activity;
        this.listActor = listActor;
    }

    @NonNull
    @Override
    public ActorViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, final int i) {
        view = LayoutInflater.from(host).inflate(R.layout.item_actor, viewGroup, false);
        final ActorViewHolder actorViewHolder = new ActorViewHolder(view);


        return actorViewHolder;
    }

    @Override
    public void onBindViewHolder(final @NonNull ActorViewHolder actorViewHolder, final int i) {
        Actor actor = listActor.get(i);
        //actorViewHolder.actorImage.setImageResource(actor.getActorImage());
        toolUtil.setCircularImage(host, actor.getActorImage(), actorViewHolder.actorImage);
        actorViewHolder.actorName.setText(actor.getActorName());
        //actorViewHolder.actorTotal.setText(actor.getTotal() + "");
        actorViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(host, ActorDetailActivity.class);
                //Toast.makeText(context, "Test" + String.valueOf(actorViewHolder.getAdapterPosition()), Toast.LENGTH_SHORT).show();
                //context.startActivity(intent);
                host.startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(
                        host, actorViewHolder.actorImage, actorViewHolder.actorImage.getTransitionName()).toBundle());
            }
        });
    }

    @Override
    public int getItemCount() {
        return listActor.size();
    }


    public class ActorViewHolder extends RecyclerView.ViewHolder {
        ImageView actorImage, imgPlay;
        TextView actorName, actorTotal;

        public ActorViewHolder(@NonNull View itemView) {
            super(itemView);
            actorImage = itemView.findViewById(R.id.imgImageActorItem);
            imgPlay = itemView.findViewById(R.id.imgPlayActorItem);
            actorName = itemView.findViewById(R.id.txtNameActorItem);
            actorTotal = itemView.findViewById(R.id.txtSizeActorItem);
        }
    }
}
