package com.chiennx.chpplayer.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import com.chiennx.chpplayer.R;
import com.chiennx.chpplayer.adapters.PlaylistAdapter;
import com.chiennx.chpplayer.datas.DataUtil;
import com.chiennx.chpplayer.models.Playlist;

import java.util.ArrayList;

public class PlaylistFragment extends Fragment {

    View view;
    GridView gridView;
    PlaylistAdapter playlistAdapter;
    ArrayList<Playlist> playlistArrayList;

    public PlaylistFragment() {
    }

    public static PlaylistFragment newInstance() {

        Bundle args = new Bundle();

        PlaylistFragment fragment = new PlaylistFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //super.onCreateView(inflater, container, savedInstanceState);
        view = inflater.inflate(R.layout.fragment_playlist, container, false);

        gridView = view.findViewById(R.id.playlistGridView);
        playlistAdapter = new PlaylistAdapter(getContext(), playlistArrayList);
        gridView.setAdapter(playlistAdapter);

        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DataUtil dataUtil = new DataUtil();
        playlistArrayList = dataUtil.dataPlaylist();
    }
}
