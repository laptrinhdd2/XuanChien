package com.chiennx.chpplayer.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.os.Build;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chiennx.chpplayer.R;
import com.chiennx.chpplayer.adapters.ViewPagerAdapter;
import com.chiennx.chpplayer.fragments.ActorFragment;
import com.chiennx.chpplayer.fragments.FavoriteFragment;
import com.chiennx.chpplayer.fragments.PlaylistFragment;
import com.chiennx.chpplayer.fragments.SongFragment;
import com.chiennx.chpplayer.tools.ToolUtil;

public class MainActivity extends AppCompatActivity {

    private final int STORAGE_EXTERNAL_CODE = 52019;

    Toolbar toolbar;
    TabLayout tabs;
    ViewPager viewPager;
    private ViewPagerAdapter viewPagerAdapter;
    ImageView imgPlayBar, imgPrev, imgPlay, imgNext;
    LinearLayout playBarInfo;
    TextView txtSong, txtActor;
    ToolUtil toolUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        checkRuntimePermission();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponent();
        setupToolbar();
        setupTab();
        setupPlayBar();
    }

    //Initialization Component
    private void initComponent() {
        toolbar = findViewById(R.id.toolBar);
        tabs = findViewById(R.id.tabs);
        viewPager = findViewById(R.id.viewPager);
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        imgPlayBar = findViewById(R.id.imgImagePlayBar);
        imgPrev = findViewById(R.id.imgPrevPlayBar);
        imgPlay = findViewById(R.id.imgPlayPlayBar);
        imgNext = findViewById(R.id.imgNextPlayBar);
        playBarInfo = findViewById(R.id.playBarInfo);
        txtSong = findViewById(R.id.txtSongNamePlayBar);
        txtActor = findViewById(R.id.txtActorPlayBar);

        toolUtil = new ToolUtil();
    }

    //Setup Toolbar
    private void setupToolbar() {
        toolbar.setNavigationIcon(R.drawable.ic_menu);
        setSupportActionBar(toolbar);
        toolbar.getNavigationIcon().setColorFilter(-1, PorterDuff.Mode.SRC_IN);
        toolbar.setTitleTextColor(getResources().getColor(R.color.primaryTextColor));
        toolbar.getNavigationIcon().setColorFilter(-1, PorterDuff.Mode.SRC_IN);
    }

    //Setup Tabs
    private void setupTab() {
        viewPagerAdapter.addFragment(new SongFragment(), "Song");
        viewPagerAdapter.addFragment(new ActorFragment(), "Actor");
        viewPagerAdapter.addFragment(new PlaylistFragment(), "Playlist");
        viewPagerAdapter.addFragment(new FavoriteFragment(), "Favorite");

        viewPager.setAdapter(viewPagerAdapter);
        tabs.setupWithViewPager(viewPager);

        tabs.setSelectedTabIndicatorColor(getResources().getColor(R.color.secondaryDarkColor));

        //Set icon tab
        tabs.getTabAt(0).setIcon(R.drawable.ic_song);
        tabs.getTabAt(1).setIcon(R.drawable.ic_actor);
        tabs.getTabAt(2).setIcon(R.drawable.ic_playlist);
        tabs.getTabAt(3).setIcon(R.drawable.ic_favorite);

        //Icon tab color
        getSupportActionBar().setTitle("Songs");
        tabs.getTabAt(0).getIcon().setColorFilter(getResources().getColor(R.color.secondaryDarkColor), PorterDuff.Mode.SRC_IN);
        tabs.getTabAt(1).getIcon().setColorFilter(getResources().getColor(R.color.primaryTextColor), PorterDuff.Mode.SRC_IN);
        tabs.getTabAt(2).getIcon().setColorFilter(getResources().getColor(R.color.primaryTextColor), PorterDuff.Mode.SRC_IN);
        tabs.getTabAt(3).getIcon().setColorFilter(getResources().getColor(R.color.primaryTextColor), PorterDuff.Mode.SRC_IN);
        getSupportActionBar().setTitle(getResources().getString(R.string.title_song));

        tabs.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                getSupportActionBar().setTitle(viewPagerAdapter.getTitle(tab.getPosition()));
                tab.getIcon().setColorFilter(getResources().getColor(R.color.secondaryDarkColor), PorterDuff.Mode.SRC_IN);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                tab.getIcon().setColorFilter(getResources().getColor(R.color.primaryTextColor), PorterDuff.Mode.SRC_IN);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

    //Setup PlayBar
    private void setupPlayBar() {
        toolUtil.setCircularImage(this, R.drawable.img_default, imgPlayBar);
        playBarInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PlayBackControlActivity.class);
                startActivity(intent);
            }
        });

    }

    // Creating Runtime permission function.
    public void checkRuntimePermission() {
        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "No", Toast.LENGTH_SHORT).show();
            requestStoragePermission();
        } else {
            Toast.makeText(this, "Yes", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestStoragePermission() {
        if (shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)) {
            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(MainActivity.this);
            alertBuilder.setTitle("Permission");
            alertBuilder.setMessage("Read storage.");
            alertBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityCompat.requestPermissions(
                            MainActivity.this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            STORAGE_EXTERNAL_CODE
                    );
                }
            });
            alertBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            AlertDialog dialog = alertBuilder.create();
            dialog.show();
        } else {
            ActivityCompat.requestPermissions(
                    MainActivity.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    STORAGE_EXTERNAL_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if(requestCode == STORAGE_EXTERNAL_CODE) {
            if(grantResults.length > 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "No permission read storage!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
