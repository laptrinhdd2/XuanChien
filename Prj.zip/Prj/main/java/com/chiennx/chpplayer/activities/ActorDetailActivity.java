package com.chiennx.chpplayer.activities;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.transition.TransitionInflater;
import android.view.View;
import android.widget.ImageView;

import com.chiennx.chpplayer.R;
import com.chiennx.chpplayer.tools.ToolUtil;

public class ActorDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actor_detail_layout);

        ImageView actorImage = findViewById(R.id.imgImageActorItem);
        ToolUtil toolUtil = new ToolUtil();
        toolUtil.setCircularImage(this, R.drawable.img_default,actorImage);
        // check if we should used curved motion and load an appropriate transition
        boolean curve = false;
        getWindow().setSharedElementEnterTransition(TransitionInflater.from(this)
                .inflateTransition(curve ? R.transition.curve : R.transition.move));
    }
}
